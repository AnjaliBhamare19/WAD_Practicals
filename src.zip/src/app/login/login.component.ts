import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent implements OnInit{

   registeruser: any[] = [];
   registerobj: any ={
       name : '',
       password : ''
   } 
  //  private router : Router
  constructor( ){}
  ngOnInit(): void {
    
  }

  

  doLogin(Values: any){
       this.registeruser = JSON.parse(localStorage.getItem('registeruser') || "{}");
       if(this.registeruser.some((v) =>{
           return v.name === this. registerobj.name;
       }))
       {   
              alert("Login Successfull");
              //  this.router.navigate(['/showdata']);
       }
       else{
        // this.loginuser.push(this.loginobj);
        // localStorage.setItem('loginuser', JSON.stringify(this.loginuser));
        // this.loginobj = {
        //   username : '',
        //   password : ''
        // };
        alert("Login failed");   
       }

  };

}
