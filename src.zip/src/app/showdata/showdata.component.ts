import { Component } from '@angular/core';

@Component({
  selector: 'app-showdata',
  templateUrl: './showdata.component.html',
  styleUrl: './showdata.component.css'
})
export class ShowdataComponent {

  registeruser : any[] = [];
  registerobj = {
    name : '',
    email: '',
    password: '',
    mobile: '',
    dob: '',
    city: '',
    state: ''
  }

  constructor(){
    this.registeruser = JSON.parse(localStorage.getItem("registeruser") || "{}");
  }

}
