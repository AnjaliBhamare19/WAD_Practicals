import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrl: './register.component.css'
})
export class RegisterComponent implements OnInit{

   registeruser : any[] = [];
   registerobj : any= {
    name : '',
    email: '',
    password: '',
    dob: '',
    mobile: '',
    city: '',
    state: ''
   };

    constructor( private router : Router){}

    ngOnInit(): void {
      
    }


      
      

    doRegister(Values: any) {
      this.registeruser = JSON.parse(localStorage.getItem('registeruser') || "{}");
      if(this.registeruser.some((v)=>{
                 return v.name == this.registerobj.name;
      }))
      {
        alert("Duplicate Data");
      }

      else
      {
        alert("Register Successfully...");
        this.registeruser.push(this.registerobj);
        localStorage.setItem('registeruser', JSON.stringify(this.registeruser));
        this.registerobj ={
          name : '',
          email: '',
          password: '',
          dob: '',
          mobile: '',
          city: '',
          state: ''
        };

        this.router.navigate(['/showdata']);
    }
      }
}

